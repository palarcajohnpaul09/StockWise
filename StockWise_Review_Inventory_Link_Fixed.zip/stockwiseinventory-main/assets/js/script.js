/* ==========================================
   STOCKWISE - COMPLETE SYSTEM
========================================== */

const KEYS = {
    users: "sw_users",
    currentUser: "sw_currentUser",
    products: "sw_products",
    sales: "sw_sales"
};

function getData(key) {
    return JSON.parse(localStorage.getItem(key) || "[]");
}

function saveData(key, data) {
    localStorage.setItem(key, JSON.stringify(data));
}

function getCurrentUser() {
    return JSON.parse(localStorage.getItem(KEYS.currentUser) || "null");
}

function getProducts() {
    return getData(KEYS.products);
}

function getSales() {
    return getData(KEYS.sales);
}

function formatCurrency(amount) {
    return "₱" + Number(amount || 0).toLocaleString("en-PH", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

function formatDate(date) {
    if (!date) return "-";

    return new Date(date + "T00:00:00").toLocaleDateString("en-PH", {
        month: "short",
        day: "2-digit",
        year: "numeric"
    });
}

function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, char => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#039;"
    })[char]);
}

/* AUTHENTICATION */

function signup(name, email, password) {
    const users = getData(KEYS.users);

    if (users.some(user => user.email === email)) {
        return "Email already registered.";
    }

    users.push({
        id: Date.now(),
        name,
        email,
        password
    });

    saveData(KEYS.users, users);
    return true;
}

function login(email, password) {
    const users = getData(KEYS.users);

    const user = users.find(user =>
        user.email === email && user.password === password
    );

    if (!user) return false;

    localStorage.setItem(KEYS.currentUser, JSON.stringify(user));
    return true;
}

function logout() {
    localStorage.removeItem(KEYS.currentUser);
    window.location.href = "login.html";
}

/* PRODUCTS */

function addProduct(product) {
    const products = getProducts();

    product.id = Date.now();
    product.createdAt = new Date().toISOString().slice(0, 10);

    products.push(product);
    saveData(KEYS.products, products);
}

function updateProduct(id, updatedProduct) {
    const products = getProducts();

    const index = products.findIndex(p => String(p.id) === String(id));

    if (index !== -1) {
        products[index] = {
            ...products[index],
            ...updatedProduct
        };

        saveData(KEYS.products, products);
    }
}

function deleteProduct(id) {
    saveData(
        KEYS.products,
        getProducts().filter(p => String(p.id) !== String(id))
    );
}

function getStockStatus(product) {
    const quantity = Number(product.quantity) || 0;
    const reorderLevel = Number(product.reorderLevel) || 0;

    if (quantity <= 0) return "Out of Stock";
    if (quantity <= reorderLevel) return "Low Stock";

    return "In Stock";
}

/* SALES */

function recordSale(productId, quantity) {
    const products = getProducts();

    const product = products.find(p => String(p.id) === String(productId));

    quantity = Number(quantity);

    if (!product) return "Product not found.";
    if (quantity <= 0) return "Enter a valid quantity.";
    if (quantity > Number(product.quantity)) {
        return "Not enough stock available.";
    }

    const total = quantity * Number(product.price);

    product.quantity -= quantity;
    saveData(KEYS.products, products);

    const sales = getSales();

    sales.push({
        id: Date.now(),
        productId: product.id,
        productName: product.name,
        quantity,
        price: Number(product.price),
        total,
        date: new Date().toISOString().slice(0, 10)
    });

    saveData(KEYS.sales, sales);

    return true;
}

/* EXPIRATION */

function getExpirationStatus(product) {
    if (!product.expirationDate) return "No Expiration Date";

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const expiration = new Date(product.expirationDate + "T00:00:00");
    const days = Math.ceil((expiration - today) / 86400000);

    if (days < 0) return "Expired";
    if (days <= 7) return "Expiring Soon";

    return "Good";
}

/* FRESHSAVE RESCUE PLANNER — expiration-based waste prevention */
function generateFreshSavePlan() {
    const today = new Date(); today.setHours(0,0,0,0);
    const candidates = getProducts().filter(p => p.expirationDate).map(p => {
        const expiry = new Date(p.expirationDate + "T00:00:00");
        const daysLeft = Math.ceil((expiry - today) / 86400000);
        let priority, action, badge;
        if (daysLeft < 0) { priority = 0; action = "Remove from sale and review disposal/return policy."; badge = "Expired"; }
        else if (daysLeft <= 3) { priority = 1; action = "Prioritize selling today; consider a manager-approved markdown."; badge = "Urgent"; }
        else if (daysLeft <= 7) { priority = 2; action = "Move to the front shelf and feature in a short-term promotion."; badge = "Soon"; }
        else if (daysLeft <= 14) { priority = 3; action = "Apply first-expiring, first-out (FEFO) stock rotation."; badge = "Plan ahead"; }
        else return null;
        return { name: p.name, quantity: Number(p.quantity || 0), daysLeft, priority, action, badge };
    }).filter(Boolean).sort((a,b) => a.priority-b.priority || a.daysLeft-b.daysLeft);
    const count = document.getElementById("rescueCount");
    const output = document.getElementById("freshSaveResults");
    if (count) count.textContent = candidates.length;
    if (!output) return;
    if (!candidates.length) { output.innerHTML = '<div class="alert alert-success mb-0">Great! No products are within the 14-day rescue window.</div>'; return; }
    output.innerHTML = `<div class="table-responsive"><table class="table align-middle"><thead><tr><th>Priority</th><th>Product</th><th>Qty</th><th>Time left</th><th>Suggested action</th></tr></thead><tbody>${candidates.map(item => `<tr><td><span class="status-badge ${item.daysLeft < 0 ? 'status-expired' : 'status-expiring'}">${item.badge}</span></td><td><strong>${escapeHTML(item.name)}</strong></td><td>${item.quantity}</td><td>${item.daysLeft < 0 ? Math.abs(item.daysLeft)+' day(s) overdue' : item.daysLeft+' day(s)'}</td><td>${item.action}</td></tr>`).join('')}</tbody></table></div><small class="text-muted">Suggestions are decision support only. Confirm product condition and follow store policy before discounting or disposing of items.</small>`;
}

/* FORECASTING */

function forecastDemand(productId) {
    const sales = getSales().filter(
        sale => String(sale.productId) === String(productId)
    );

    if (!sales.length) return 0;

    const total = sales.reduce(
        (sum, sale) => sum + Number(sale.quantity), 0
    );

    return Math.ceil(total / Math.max(1, sales.length) * 7);
}

/* REORDER */

function getReorderRecommendations() {
    return getProducts().filter(product =>
        Number(product.quantity) <= Number(product.reorderLevel)
    );
}

/* REPORTS */

function getSalesReport() {
    const sales = getSales();

    return {
        transactions: sales.length,
        itemsSold: sales.reduce((sum, sale) => sum + Number(sale.quantity), 0),
        revenue: sales.reduce((sum, sale) => sum + Number(sale.total), 0)
    };
}

/* SHARED PAGE DESIGN */

const pageNames = {
    dashboard: "Dashboard",
    products: "Products",
    inventory: "Inventory",
    sales: "Sales",
    expiration: "Expiration",
    forecasting: "Forecasting",
    reorder: "Reorder",
    reports: "Reports",
    account: "Manage Account"
};

function sidebar(active) {
    const links = [
        ["dashboard", "grid-fill", "Dashboard"],
        ["products", "box-seam", "Products"],
        ["inventory", "clipboard-data", "Inventory"],
        ["sales", "cart-check", "Sales"],
        ["expiration", "calendar2-week", "Expiration"],
        ["forecasting", "graph-up-arrow", "Forecasting"],
        ["reorder", "arrow-repeat", "Reorder"],
        ["reports", "file-earmark-bar-graph", "Reports"],
        ["account", "person-gear", "Manage Account"]
    ];

    return `
        <aside class="sidebar">
            <a href="dashboard.html" class="sidebar-brand">
                <i class="bi bi-box-seam-fill"></i>
                StockWise
            </a>

            <div class="sidebar-label">MAIN MENU</div>

            <nav class="nav flex-column">
                ${links.slice(0, 5).map(link => `
                    <a href="${link[0]}.html"
                       class="nav-link ${active === link[0] ? "active" : ""}">
                        <i class="bi bi-${link[1]}"></i>
                        <span>${link[2]}</span>
                    </a>
                `).join("")}
            </nav>

            <div class="sidebar-label">ANALYTICS</div>

            <nav class="nav flex-column">
                ${links.slice(5).map(link => `
                    <a href="${link[0]}.html"
                       class="nav-link ${active === link[0] ? "active" : ""}">
                        <i class="bi bi-${link[1]}"></i>
                        <span>${link[2]}</span>
                    </a>
                `).join("")}
            </nav>

            <div class="sidebar-bottom">
                <a href="#" onclick="logout()" class="nav-link">
                    <i class="bi bi-box-arrow-right"></i>
                    <span>Logout</span>
                </a>
            </div>
        </aside>
    `;
}

function metric(title, value, icon, color, note = "") {
    return `
        <div class="col-md-6 col-xl-3">
            <div class="metric-card">
                <div class="metric-icon icon-${color}">
                    <i class="bi bi-${icon}"></i>
                </div>
                <div class="metric-title">${title}</div>
                <div class="metric-value">${value}</div>
                <div class="metric-note text-muted">${note}</div>
            </div>
        </div>
    `;
}

function table(headers, rows) {
    return `
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>${headers.map(h => `<th>${h}</th>`).join("")}</tr>
                </thead>
                <tbody>
                    ${rows.length ? rows.join("") :
                        `<tr><td colspan="${headers.length}" class="text-center text-muted">No records found.</td></tr>`}
                </tbody>
            </table>
        </div>
    `;
}

function shell(page, content) {
    const user = getCurrentUser();

    if (!user) {
        window.location.href = "login.html";
        return;
    }

    document.title = pageNames[page] + " | StockWise";

    document.body.innerHTML = `
        <div class="app-layout">
            ${sidebar(page)}

            <main class="main-content">
                <header class="topbar">
                    <div>
                        <h5>${pageNames[page]}</h5>
                        <small class="text-muted">StockWise Inventory Management</small>
                    </div>

                    <div class="user-profile">
                        <div class="user-avatar">
                            <i class="bi bi-person-fill"></i>
                        </div>
                        <span>${escapeHTML(user.name)}</span>
                    </div>
                </header>

                <div class="content-area">
                    ${content}
                    <footer>© 2026 StockWise. Predictive Inventory Management System.</footer>
                </div>
            </main>
        </div>
    `;
}

/* DASHBOARD */


/* ==========================================
   CREATIVE UI INTERACTIONS
   - Context tips for each feature
   - Live inventory notification center
========================================== */
function getStockWiseAlerts(){
    const products=getProducts();
    const low=products.filter(p=>getStockStatus(p)!=="In Stock");
    const exp=products.filter(p=>["Expired","Expiring Soon"].includes(getExpirationStatus(p)));
    const alerts=[];
    low.forEach(p=>alerts.push({icon:"bi-box-seam",title:p.name||"Product",message:`${getStockStatus(p)} · ${Number(p.quantity)||0} unit(s) remaining`,type:"stock"}));
    exp.forEach(p=>alerts.push({icon:"bi-calendar2-x",title:p.name||"Product",message:`${getExpirationStatus(p)} · Check expiration date`,type:"expiry"}));
    return alerts;
}
function addStockWiseCreativeUI(page){
    const topbar=document.querySelector(".topbar");
    if(!topbar)return;
    const user=topbar.querySelector(".user-profile");
    if(user&&!document.querySelector(".sw-notification-wrap")){
        const alerts=getStockWiseAlerts();
        const wrap=document.createElement("div");wrap.className="sw-notification-wrap";
        wrap.innerHTML=`<button class="sw-notification-btn" type="button" aria-label="Inventory notifications" aria-expanded="false"><i class="bi bi-bell"></i><span class="sw-notification-count">${alerts.length>9?"9+":alerts.length}</span></button><div class="sw-notification-panel"><div class="sw-notification-heading"><span>Inventory alerts</span><small>${alerts.length} NEED ATTENTION</small></div>${alerts.length?alerts.slice(0,7).map(a=>`<div class="sw-alert-item"><i class="bi ${a.icon}"></i><div><strong>${escapeHTML(a.title)}</strong>${escapeHTML(a.message)}</div></div>`).join(""):`<div class="sw-alert-empty"><i class="bi bi-check-circle me-1"></i> Everything looks good. No urgent alerts.</div>`}<a href="inventory.html" class="btn btn-outline-primary btn-sm w-100 mt-2 sw-review-inventory">Review inventory</a></div>`;
        topbar.insertBefore(wrap,user);
        const btn=wrap.querySelector("button"),panel=wrap.querySelector(".sw-notification-panel");
        const reviewLink=wrap.querySelector(".sw-review-inventory");
        btn.addEventListener("click",e=>{e.preventDefault();e.stopPropagation();const open=panel.classList.toggle("is-open");btn.setAttribute("aria-expanded",String(open));});
        // Use an explicit same-folder URL so the link works from every page in /pages.
        reviewLink.addEventListener("click",e=>{
            e.preventDefault();
            window.location.href=new URL("inventory.html",window.location.href).href;
        });
        panel.addEventListener("click",e=>e.stopPropagation());
        document.addEventListener("click",e=>{if(!wrap.contains(e.target)){panel.classList.remove("is-open");btn.setAttribute("aria-expanded","false");}});
    }
    const tips={
      dashboard:["bi-stars","Your command center","Track sales performance, inventory health, and important actions from one place."],
      products:["bi-box-seam","Build your product catalog","Keep product names, categories, prices, stock levels, and reorder points organized."],
      inventory:["bi-clipboard2-pulse","Stay ahead of stock changes","Use stock status and inventory levels to spot products that need attention."],
      sales:["bi-cart-check","Every sale updates your stock","Record transactions accurately to keep available quantities and sales history up to date."],
      expiration:["bi-calendar2-check","Protect products from expiring","Review expiration dates regularly and prioritize items that are expired or nearing expiry."],
      forecasting:["bi-graph-up-arrow","Plan your next replenishment","Use recorded sales activity as a guide when estimating upcoming product demand."],
      reorder:["bi-arrow-repeat","Replenish with confidence","Compare current stock with reorder levels before deciding what and how much to purchase."],
      reports:["bi-bar-chart-line","Turn records into business insights","Review transaction history and performance summaries to support better decisions."],
      account:["bi-shield-check","Keep your account up to date","Manage your profile and password details from one convenient place."]
    };
    const tip=tips[page],area=document.querySelector(".content-area");
    if(tip&&area&&!area.querySelector(".sw-page-insight")){
      const banner=document.createElement("div");banner.className="sw-page-insight";
      banner.innerHTML=`<i class="bi ${tip[0]}"></i><div><strong>${tip[1]}</strong><br>${tip[2]}</div>`;
      const first=area.querySelector(".dashboard-welcome,.page-header,.row,.content-card");
      if(first)area.insertBefore(banner,first);else area.prepend(banner);
    }
}

